package com.example.demo.service;

import com.example.demo.models.GameAuthor;
import com.example.demo.repositories.GameAuthorRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class GameAuthorServiceTest {

    @Mock
    private GameAuthorRepository gameAuthorRepository;

    @Mock
    private EmailService emailService;

    @InjectMocks
    private GameAuthorService gameAuthorService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetAllGameAuthors() {
        GameAuthor author1 = new GameAuthor("Nickname1", LocalDate.of(1980, 1, 1));
        GameAuthor author2 = new GameAuthor("Nickname2", LocalDate.of(1990, 1, 1));
        List<GameAuthor> authors = Arrays.asList(author1, author2);

        when(gameAuthorRepository.findAll()).thenReturn(authors);

        List<GameAuthor> result = gameAuthorService.getAllGameAuthors();
        assertEquals(2, result.size());
        assertEquals(authors, result);
    }

    @Test
    public void testCreateGameAuthor() {
        GameAuthor gameAuthor = new GameAuthor("Nickname1", LocalDate.of(1980, 1, 1));

        when(gameAuthorRepository.save(gameAuthor)).thenReturn(gameAuthor);

        GameAuthor result = gameAuthorService.createGameAuthor(gameAuthor);

        assertEquals(gameAuthor, result);
        verify(emailService, times(1)).sendGameAuthorCreatedEmail(gameAuthor);
    }

    @Test
    public void testDeleteGameAuthor() {
        Long id = 1L;
        doNothing().when(gameAuthorRepository).deleteById(id);

        gameAuthorService.deleteGameAuthor(id);

        verify(gameAuthorRepository, times(1)).deleteById(id);
    }

    @Test
    public void testGetGameAuthorById() {
        Long id = 1L;
        GameAuthor gameAuthor = new GameAuthor("Nickname1", LocalDate.of(1980, 1, 1));

        when(gameAuthorRepository.findById(id)).thenReturn(Optional.of(gameAuthor));

        GameAuthor result = gameAuthorService.getGameAuthorById(id);

        assertEquals(gameAuthor, result);
    }
}
