package com.example.demo.service;

import com.example.demo.models.User;
import com.example.demo.repositories.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class UserServiceTest {

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private UserService userService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testSaveUser() {
        // Создаем тестового пользователя
        User testUser = new User();
        testUser.setUsername("testuser");
        testUser.setEmail("test@example.com");

        // Настроим поведение заглушки userRepository для сохранения пользователя
        when(userRepository.save(testUser)).thenReturn(testUser);

        // Вызываем метод сервиса для сохранения пользователя
        userService.save(testUser);

        // Проверяем, что метод save был вызван ровно один раз с нашим тестовым пользователем
        verify(userRepository, times(1)).save(testUser);
    }

    @Test
    public void testFindByUsername() {
        // Создаем тестового пользователя
        User testUser = new User();
        testUser.setUsername("testuser");
        testUser.setEmail("test@example.com");

        // Настроим поведение заглушки userRepository для поиска пользователя по имени
        when(userRepository.findByUsername("testuser")).thenReturn(testUser);

        // Вызываем метод сервиса для поиска пользователя по имени
        User foundUser = userService.findByUsername("testuser");

        // Проверяем, что возвращенный пользователь совпадает с ожидаемым
        assertEquals(testUser, foundUser);
    }
}
