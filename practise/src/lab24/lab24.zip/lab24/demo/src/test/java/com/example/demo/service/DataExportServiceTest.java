package com.example.demo.service;

import com.example.demo.models.Game;
import com.example.demo.models.GameAuthor;
import com.example.demo.repositories.GameRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class DataExportServiceTest {

    @Mock
    private GameRepository gameRepository;

    @Mock
    private DirectoryCleaner directoryCleaner;

    @InjectMocks
    private DataExportService dataExportService;

    @BeforeEach
    public void setUp() {
        dataExportService.setDirectoryPath("test_directory");
    }

    @Test
    public void testExportDataAndClearDirectory() throws IOException {
        // Создаем тестовые данные
        GameAuthor author = new GameAuthor();
        Game game1 = new Game();
        game1.setName("Game 1");
        game1.setCreationDate(LocalDate.now());
        game1.setAuthor(author);

        Game game2 = new Game();
        game2.setName("Game 2");
        game2.setCreationDate(LocalDate.now());
        game2.setAuthor(author);

        List<Game> games = Arrays.asList(game1, game2);

        // Настраиваем заглушки
        when(gameRepository.findAll()).thenReturn(games);

        // Вызываем метод экспорта данных
        dataExportService.exportDataAndClearDirectory();

        // Проверяем, что метод очистки каталога был вызван
        verify(directoryCleaner, times(1)).clearDirectory();

        // Проверяем, что данные были сохранены в файл
        String expectedFileName = "test_directory" + File.separator + "games_" + LocalDateTime.now().
                format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".txt";
        File file = new File(expectedFileName);
        try (FileWriter fileWriter = new FileWriter(file)) {
            for (Game game : games) {
                fileWriter.write(game.toString() + "\n");
            }
        }

        // Проверяем, что файл был создан
        assertEquals(true, file.exists());

        // Удаляем тестовый файл
        file.delete();
    }
}
