package com.example.demo.service;

import com.example.demo.models.Game;
import com.example.demo.repositories.GameRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class GameServiceTest {

    @Mock
    private GameRepository gameRepository;

    @Mock
    private EmailService emailService;

    @InjectMocks
    private GameService gameService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetAllGames() {
        Game game1 = new Game("Game1", LocalDate.of(2023, 1, 1));
        Game game2 = new Game("Game2", LocalDate.of(2023, 1, 2));
        List<Game> games = Arrays.asList(game1, game2);

        when(gameRepository.findAll()).thenReturn(games);

        List<Game> result = gameService.getAllGames();
        assertEquals(2, result.size());
        assertEquals(games, result);
    }

    @Test
    public void testCreateGame() {
        Game game = new Game("Game1", LocalDate.of(2023, 1, 1));

        when(gameRepository.save(game)).thenReturn(game);

        Game result = gameService.createGame(game);

        assertEquals(game, result);
        verify(emailService, times(1)).sendGameCreatedEmail(game);
    }

    @Test
    public void testDeleteGame() {
        Long id = 1L;
        doNothing().when(gameRepository).deleteById(id);

        gameService.deleteGame(id);

        verify(gameRepository, times(1)).deleteById(id);
    }

    @Test
    public void testGetGameById() {
        Long id = 1L;
        Game game = new Game("Game1", LocalDate.of(2023, 1, 1));

        when(gameRepository.findById(id)).thenReturn(Optional.of(game));

        Game result = gameService.getGameById(id);

        assertEquals(game, result);
    }
}
