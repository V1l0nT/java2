package com.example.demo.service;

import com.example.demo.models.GameAuthor;
import com.example.demo.repositories.GameAuthorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;

@Service
public class GameAuthorService {

    private static final Logger logger = LoggerFactory.getLogger(GameAuthorService.class);

    @Autowired
    public GameAuthorRepository gameAuthorRepository;

    @Autowired
    public EmailService emailService;

    @Transactional(readOnly = true)
    public List<GameAuthor> getAllGameAuthors() {
        logger.debug("Fetching all game authors");
        return gameAuthorRepository.findAll();
    }

    @Transactional
    public GameAuthor createGameAuthor(GameAuthor gameAuthor) {
        logger.debug("Creating new game author: {}", gameAuthor);
        GameAuthor createdGameAuthor = gameAuthorRepository.save(gameAuthor);
        emailService.sendGameAuthorCreatedEmail(createdGameAuthor);
        return createdGameAuthor;
    }

    @Transactional
    public void deleteGameAuthor(Long id) {
        logger.debug("Deleting game author with id: {}", id);
        gameAuthorRepository.deleteById(id);
    }

    @Transactional(readOnly = true)
    public List<GameAuthor> filterGameAuthors(Map<String, Object> filters) {
        logger.debug("Filtering game authors with filters: {}", filters);
        return gameAuthorRepository.filterGameAuthors(filters);
    }

    @Transactional(readOnly = true)
    public GameAuthor getGameAuthorById(Long id) {
        logger.debug("Fetching game author with id: {}", id);
        return gameAuthorRepository.findById(id).orElse(null);
    }
}
