package com.example.demo;

import com.example.demo.models.Game;
import com.example.demo.models.GameAuthor;
import com.example.demo.repositories.GameAuthorRepository;
import com.example.demo.repositories.GameRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

@Component
public class DataLoader implements CommandLineRunner {

    @Autowired
    private GameAuthorRepository gameAuthorRepository;

    @Autowired
    private GameRepository gameRepository;

    @Override
    public void run(String... args) throws Exception {
        GameAuthor author1 = new GameAuthor();
        author1.setNickname("JohnDoe");
        author1.setBirthDate(LocalDate.of(1985, 1, 1));
        gameAuthorRepository.save(author1);

        Game game1 = new Game();
        game1.setName("Super Game");
        game1.setCreationDate(LocalDate.of(2020, 1, 1));
        game1.setAuthor(author1);
        gameRepository.save(game1);

        Game game2 = new Game();
        game2.setName("Another Game");
        game2.setCreationDate(LocalDate.of(2021, 2, 1));
        game2.setAuthor(author1);
        gameRepository.save(game2);
    }
}
