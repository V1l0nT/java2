package com.example.demo.service;

import com.example.demo.models.Game;
import com.example.demo.models.GameAuthor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    private static final Logger logger = LoggerFactory.getLogger(EmailService.class);

    private AsyncTaskExecutor taskExecutor;

    public void setTaskExecutor(AsyncTaskExecutor taskExecutor) {
        this.taskExecutor = taskExecutor;
    }

    @Async
    public void sendGameCreatedEmail(Game game) {
        logger.debug("Отправка email уведомления о создании игры: {}", game.getName());
        // код отправки email...
    }

    @Async
    public void sendGameAuthorCreatedEmail(GameAuthor gameAuthor) {
        logger.debug("Отправка email уведомления о создании автора игры: {}", gameAuthor.getNickname());
        // код отправки email...
    }
}
