package com.example.demo.repositories;

import com.example.demo.models.Game;

import java.time.LocalDate;
import java.util.List;

public interface GameRepositoryCustom {
    List<Game> filterGames(String name, LocalDate creationDate);
}
