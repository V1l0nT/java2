package com.example.demo.controllers;

import com.example.demo.models.GameAuthor;
import com.example.demo.service.GameAuthorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/game-authors")
public class GameAuthorController {

    @Autowired
    private GameAuthorService gameAuthorService;

    @GetMapping
    public List<GameAuthor> getAllGameAuthors() {
        return gameAuthorService.getAllGameAuthors();
    }

    @PostMapping
    public GameAuthor createGameAuthor(@RequestBody GameAuthor gameAuthor) {
        return gameAuthorService.createGameAuthor(gameAuthor);
    }

    @DeleteMapping("/{id}")
    public void deleteGameAuthor(@PathVariable Long id) {
        gameAuthorService.deleteGameAuthor(id);
    }

    @GetMapping("/filter")
    public List<GameAuthor> filterGameAuthors(@RequestParam Map<String, Object> filters) {
        return gameAuthorService.filterGameAuthors(filters);
    }

    @GetMapping("/{id}")
    public GameAuthor getGameAuthorById(@PathVariable Long id) {
        return gameAuthorService.getGameAuthorById(id);
    }
}
