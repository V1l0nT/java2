package com.example.demo.controllers;

import com.example.demo.models.GameAuthor;
import com.example.demo.repositories.GameAuthorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/game-authors")
public class GameAuthorController {

    @Autowired
    private GameAuthorRepository gameAuthorRepository;

    @GetMapping
    public List<GameAuthor> getAllGameAuthors() {
        return gameAuthorRepository.findAll();
    }

    @PostMapping
    public GameAuthor createGameAuthor(@RequestBody GameAuthor gameAuthor) {
        return gameAuthorRepository.save(gameAuthor);
    }

    @DeleteMapping("/{id}")
    public void deleteGameAuthor(@PathVariable Long id) {
        gameAuthorRepository.deleteById(id);
    }
}
