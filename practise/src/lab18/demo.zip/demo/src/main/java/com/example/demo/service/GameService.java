package com.example.demo.service;

import com.example.demo.models.Game;
import com.example.demo.repositories.GameRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Service
public class GameService {

    @Autowired
    private GameRepository gameRepository;

    public List<Game> getAllGames() {
        return gameRepository.findAll();
    }

    public Game createGame(Game game) {
        return gameRepository.save(game);
    }

    public void deleteGame(Long id) {
        gameRepository.deleteById(id);
    }

    public List<Game> filterGames(Map<String, String> filters) {
        String name = filters.get("name");
        LocalDate creationDate = null;
        if (filters.containsKey("creationDate")) {
            creationDate = LocalDate.parse(filters.get("creationDate"));
        }
        return gameRepository.filterGames(name, creationDate);
    }

    public Game getGameById(Long id) {
        return gameRepository.findById(id).orElse(null);
    }
}
