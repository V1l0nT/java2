package com.example.demo.repositories;

import com.example.demo.models.Game;
import java.util.List;
import java.util.Map;

public interface GameRepositoryCustom {
    List<Game> filterGames(Map<String, Object> filters);
}
