package com.example.demo.repositories;

import com.example.demo.models.GameAuthor;
import java.util.List;
import java.util.Map;

public interface GameAuthorRepositoryCustom {
    List<GameAuthor> filterGameAuthors(Map<String, Object> filters);
}
