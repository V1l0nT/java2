package com.example.demo.repositories;

import com.example.demo.models.GameAuthor;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Repository
public class GameAuthorRepositoryCustomImpl implements GameAuthorRepositoryCustom {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public List<GameAuthor> filterGameAuthors(Map<String, Object> filters) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<GameAuthor> query = cb.createQuery(GameAuthor.class);
        Root<GameAuthor> root = query.from(GameAuthor.class);

        List<Predicate> predicates = new ArrayList<>();

        filters.forEach((field, value) -> {
            if (value != null && StringUtils.hasText(value.toString())) {
                predicates.add(cb.equal(root.get(field), value));
            }
        });

        query.where(predicates.toArray(new Predicate[0]));

        return entityManager.createQuery(query).getResultList();
    }
}
