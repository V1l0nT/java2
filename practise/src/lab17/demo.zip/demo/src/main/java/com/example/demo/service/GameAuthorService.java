package com.example.demo.service;

import com.example.demo.models.GameAuthor;
import com.example.demo.repositories.GameAuthorRepository;
import com.example.demo.repositories.GameAuthorRepositoryCustom;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class GameAuthorService {

    @Autowired
    private GameAuthorRepository gameAuthorRepository;

    @Qualifier("gameAuthorRepositoryCustomImpl")
    @Autowired
    private GameAuthorRepositoryCustom gameAuthorRepositoryCustom;

    public List<GameAuthor> filterGameAuthors(Map<String, Object> filters) {
        return gameAuthorRepositoryCustom.filterGameAuthors(filters);
    }

    public List<GameAuthor> getAllGameAuthors() {
        return gameAuthorRepository.findAll();
    }

    public GameAuthor createGameAuthor(GameAuthor gameAuthor) {
        return gameAuthorRepository.save(gameAuthor);
    }

    public void deleteGameAuthor(Long id) {
        gameAuthorRepository.deleteById(id);
    }

    public GameAuthor getGameAuthorById(Long id) {
        return gameAuthorRepository.findById(id).orElse(null);
    }
}
