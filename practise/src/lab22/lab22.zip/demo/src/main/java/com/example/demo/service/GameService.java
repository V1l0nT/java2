package com.example.demo.service;

import com.example.demo.models.Game;
import com.example.demo.repositories.GameRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Service
public class GameService {

    private static final Logger logger = LoggerFactory.getLogger(GameService.class);

    @Autowired
    private GameRepository gameRepository;

    @Autowired
    private EmailService emailService;

    @Transactional(readOnly = true)
    public List<Game> getAllGames() {
        logger.debug("Fetching all games");
        return gameRepository.findAll();
    }

    @Transactional
    public Game createGame(Game game) {
        logger.debug("Creating new game: {}", game);
        Game createdGame = gameRepository.save(game);
        emailService.sendGameCreatedEmail(createdGame);
        return createdGame;
    }

    @Transactional
    public void deleteGame(Long id) {
        logger.debug("Deleting game with id: {}", id);
        gameRepository.deleteById(id);
    }

    @Transactional(readOnly = true)
    public List<Game> filterGames(Map<String, String> filters) {
        String name = filters.get("name");
        LocalDate creationDate = null;
        if (filters.containsKey("creationDate")) {
            creationDate = LocalDate.parse(filters.get("creationDate"));
        }

        logger.debug("Filtering games with filters - name: {}, creationDate: {}", name, creationDate);
        return gameRepository.filterGames(name, creationDate);
    }

    @Transactional(readOnly = true)
    public Game getGameById(Long id) {
        logger.debug("Fetching game with id: {}", id);
        return gameRepository.findById(id).orElse(null);
    }
}
