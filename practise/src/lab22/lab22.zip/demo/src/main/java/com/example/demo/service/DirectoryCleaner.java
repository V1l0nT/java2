package com.example.demo.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.File;

@Component
public class DirectoryCleaner {

    @Value("${directory.path}") // Путь к директории, который может быть задан в файле application.properties
    private String directoryPath;

    public void clearDirectory() {
        File directory = new File(directoryPath);

        if (!directory.exists()) {
            // Если директория не существует, ее нужно создать
            directory.mkdirs();
        } else {
            // Если директория существует, удаляем все файлы в ней
            File[] files = directory.listFiles();
            if (files != null) {
                for (File file : files) {
                    file.delete();
                }
            }
        }
    }
}
