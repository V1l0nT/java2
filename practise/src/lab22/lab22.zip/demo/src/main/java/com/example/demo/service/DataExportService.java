package com.example.demo.service;

import com.example.demo.models.Game;
import com.example.demo.repositories.GameRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import javax.management.MBeanServer;
import javax.management.ObjectName;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class DataExportService implements DataExportServiceMBean {

    @Autowired
    private GameRepository gameRepository;

    @Autowired
    private DirectoryCleaner directoryCleaner;

    @Value("${directory.path}")
    private String directoryPath;

    public DataExportService() {
        try {
            MBeanServer mbs = ManagementFactory.getPlatformMBeanServer();
            ObjectName name = new ObjectName("com.example.demo.service:type=DataExportService");
            mbs.registerMBean(this, name);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Async
    @Scheduled(fixedRate = 1800000) // Вызов каждые 30 минут (30 минут = 1800000 миллисекунд)
    public void exportDataAndClearDirectory() {
        directoryCleaner.clearDirectory();
        exportGameData();
    }

    // Метод для экспорта данных о играх в файл
    private void exportGameData() {
        List<Game> games = gameRepository.findAll();

        String fileName = directoryPath + File.separator + "games_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".txt";

        try (FileWriter fileWriter = new FileWriter(fileName)) {
            for (Game game : games) {
                fileWriter.write(game.toString() + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Метод JMX для ручного вызова
    @Override
    public void triggerExportDataAndClearDirectory() {
        exportDataAndClearDirectory();
    }
}
