package com.example.demo.service;

import com.example.demo.models.Game;
import com.example.demo.repositories.GameRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class DataExportService {

    @Autowired
    private GameRepository gameRepository;

    // Метод для очистки директории и экспорта данных в файлы
    @Async
    public void exportDataAndClearDirectory() {
        // Очистка директории
        clearDirectory();

        // Экспорт данных
        exportGameData();
    }

    // Метод для очистки директории
    private void clearDirectory() {
        File directory = new File(directoryPath);

        if (!directory.exists()) {
            // Если директория не существует, ее нужно создать
            directory.mkdirs();
        } else {
            // Если директория существует, удаляем все файлы в ней
            File[] files = directory.listFiles();
            if (files != null) {
                for (File file : files) {
                    file.delete();
                }
            }
        }
    }

    // Метод для экспорта данных о играх в файл
    private void exportGameData() {
        List<Game> games = gameRepository.findAll();

        String fileName = "games_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".txt";

        try (FileWriter fileWriter = new FileWriter(fileName)) {
            for (Game game : games) {
                fileWriter.write(game.toString() + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
