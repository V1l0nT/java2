package com.example.demo.service;

import com.example.demo.models.Game;
import com.example.demo.models.GameAuthor;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class EmailService {

    private static final Logger logger = LoggerFactory.getLogger(EmailService.class);

    @Async
    public void sendGameCreatedEmail(Game game) {
        // Логика отправки email
        logger.debug("Sending email notification for game creation: {}", game.getName());
    }

    @Async
    public void sendGameAuthorCreatedEmail(GameAuthor gameAuthor) {
        // Логика отправки email
        logger.debug("Sending email notification for game author creation: {}", gameAuthor.getNickname());
    }
}
