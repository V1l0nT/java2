package com.example.demo.repositories;

import com.example.demo.models.Game;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Repository
public class GameRepositoryCustomImpl implements GameRepositoryCustom {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public List<Game> filterGames(String name, LocalDate creationDate) {
        StringBuilder queryString = new StringBuilder("SELECT g FROM Game g WHERE 1=1");
        List<Object> parameters = new ArrayList<>();

        if (name != null && !name.isEmpty()) {
            queryString.append(" AND g.name = ?1");
            parameters.add(name);
        }

        if (creationDate != null) {
            queryString.append(" AND g.creationDate = ?2");
            parameters.add(creationDate);
        }

        TypedQuery<Game> query = entityManager.createQuery(queryString.toString(), Game.class);

        for (int i = 0; i < parameters.size(); i++) {
            query.setParameter(i + 1, parameters.get(i));
        }

        return query.getResultList();
    }
}
